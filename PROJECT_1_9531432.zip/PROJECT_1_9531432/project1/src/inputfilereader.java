import java.io.*;
import java.nio.charset.Charset;
/*
we use this class to read from file and put them into array of chars
 */
public class inputfilereader {
    public char[] read(String s) throws IOException {
    char[] array = new char[800000];
    int p = 0;
    BufferedReader reader = new BufferedReader(
            new InputStreamReader(
                    new FileInputStream(s),
                    Charset.forName("UTF-8")));
    int c;
    while ((c = reader.read()) != -1) {
        array[p] = (char) c;
        p++;

    }
        return array;
}
}
