import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/*
we use this class to write in the file that you give the address of that file
 */
public class outputfilewriter1 {
    public  void write(String s, int[] arra) throws FileNotFoundException, UnsupportedEncodingException {
        PrintWriter writer = new PrintWriter(s, "UTF-8");
        for(int i=0;i<arra.length;i++) {
         if(arra[i]!=0)
            writer.println(arra[i]);
        }
            writer.close();

    }
    public  void write1(String s, char[] arra) throws FileNotFoundException, UnsupportedEncodingException {
        PrintWriter writer = new PrintWriter(s, "UTF-8");
        for(int i=0;i<arra.length;i++) {
         if(arra[i]!=0)
            writer.print(arra[i]);
        }
        writer.close();
    }
}
