import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import static java.lang.StrictMath.pow;

public class Coding1 {

    public static void main(String[] args) throws IOException {
        Coding1 c=new Coding1();
        c.decode("c:\\users\\mahnoosh\\desktop\\cc.txt");


    }
    //////////////////////////////////


/*we use this method to read the file and change it to the array of bytes

 */
    private static byte[] readBytesFromFile(String filePath) {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {

            File file = new File(filePath);
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        return bytesArray;

    }
    /*we use this method to change array of bytes to the array of zero and one and after that remove them into base two
     and find the code of them in the list of keys and values


     */

    public void encode(String fileName) {
        //"C:\\users\\mahnoosh\\desktop\\cc.txt"
        /////////////////////
        HashMap<Integer, Character> list = new HashMap<>();

        //////////////////////////
        try {

            // convert file to byte[]
            byte[] bFile = readBytesFromFile(fileName);

            //java nio
            //byte[] bFile = Files.readAllBytes(new File("C:\\temp\\testing1.txt").toPath());
            //byte[] bFile = Files.readAllBytes(Paths.get("C:\\temp\\testing1.txt"));

            // save byte[] into a file
            Path path = Paths.get(fileName);
            Files.write(path, bFile);

//            System.out.println("Done");

            //Print bytes[]
            int s = bFile.length;
            int[] array = new int[8*bFile.length];
            int[] arr = new int[8*bFile.length];
            int m = 0;
            /*we use this loop to reduction the value of bytes into the array of zero and one by cleavage in two

             */
            for(int i=0;i<bFile.length;i++)
                (bFile[i])= (byte) Math.abs(bFile[i]);
            for (int i = 0; i < bFile.length; i++) {
                int x = ((int) bFile[i]);//bytes are here
                //System.out.println(x);
                while (bFile[i] != 0) {
                    array[m] = bFile[i] % 2;
                    //System.out.print(array[m]);
                    bFile[i] = (byte) (bFile[i] / 2);
                    m++;
                }

                int d = m - 1;
                int k;
                for (k = 0; k <= m - 1; k++) {
                    arr[k] = array[d];
                    //System.out.print(arr[k]);
                    d--;
                }
            }
////////////////////////////////////////////////////
            int power = 5;
            int k = m;

            int sum = 0;
            int[] ar = new int[3*bFile.length];
            int v = 0;
            int vv = 0;
            //System.out.println((int)k/6);
            /*we use this loop to abrupt the array of zero and one six by six and carry them in base two

             */
            int mod=k%6;
            for (int g = 0; g < (int) k / 6; g++) {
                sum = 0;
                power = 5;
                for (int l = vv; l <= 5 + vv; l++) {
                    int x = 1;
                    for (int q = 0; q < power; q++)
                        x *= 2;
                    int p = (int) ((int) (arr[l]) * x);
                    sum = sum + p;
                    power--;
//                    vv+=6;

                }
                vv += 6;
                // System.out.println(sum);
                ar[v] = sum;
                //System.out.println(ar[v]);
                v++;


            }
            int a[]=new int [6];
            int kk=arr.length-1;
            if(mod!=0){
                for(int e=5;e>5-mod;e--){
                    a[e]=arr[kk--];
                }
                for(int ee=0;ee<=5-mod;ee++){
                    a[ee]=0;
                }
                }
            ar[ar.length-1]=a[0]*32+a[1]*16+a[2]*8+a[3]*4+a[4]*2+a[5];
//////////////////////////////////////
            char[] result = new char[bFile.length];
            int r = 0;
////////////////////
            list.put(0, 'A');
            list.put(1, 'B');
            list.put(2, 'C');
            list.put(3, 'D');
            list.put(4, 'E');
            list.put(5, 'F');
            list.put(6, 'G');
            list.put(7, 'H');
            list.put(8, 'I');
            list.put(9, 'J');
            list.put(10, 'K');
            list.put(11, 'L');
            list.put(12, 'M');
            list.put(13, 'N');
            list.put(14, 'O');
            list.put(15, 'P');
            list.put(16, 'Q');
            list.put(17, 'R');
            list.put(18, 'S');
            list.put(19, 'T');
            list.put(20, 'U');
            list.put(21, 'V');
            list.put(22, 'W');
            list.put(23, 'X');
            list.put(24, 'Y');
            list.put(25, 'Z');
            list.put(26, 'a');
            list.put(27, 'b');
            list.put(28, 'c');
            list.put(29, 'd');
            list.put(30, 'e');
            list.put(31, 'f');
            list.put(32, 'g');
            list.put(33, 'h');
            list.put(34, 'i');
            list.put(35, 'j');
            list.put(36, 'k');
            list.put(37, 'l');
            list.put(38, 'm');
            list.put(39, 'n');
            list.put(40, 'o');
            list.put(41, 'p');
            list.put(42, 'q');
            list.put(43, 'r');
            list.put(44, 's');
            list.put(45, 't');
            list.put(46, 'u');
            list.put(47, 'v');
            list.put(48, 'w');
            list.put(49, 'x');
            list.put(50, 'y');
            list.put(51, 'z');
            list.put(52, '0');
            list.put(53, '1');
            list.put(54, '2');
            list.put(55, '3');
            list.put(56, '4');
            list.put(57, '5');
            list.put(58, '6');
            list.put(59, '7');
            list.put(60, '8');
            list.put(61, '9');
            list.put(62, '+');
            list.put(63, '/');
////////////////////
            /*use this method to find the value of keys that we find in the fore loop

             */
            for (int f = 0; f <= v - 1; f++) {
                result[r] = (list.get(Math.abs(ar[f])));
                //System.out.println(result[r]);
                r++;
            }
            outputfilewriter1 w1=new outputfilewriter1();
            w1.write1("c:\\users\\mahnoosh\\desktop\\end1.txt",result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*we use this method to read the code file and find the key oh this value and after that change it to the array
    of zero and one and after that remove them into base two and after that we have the decode text

     */

    public void decode(String fileName) throws IOException
    {
        File ff=new File(fileName);
        char[] array = new char[(int) ff.length()];
        inputfilereader r1=new inputfilereader();
        array=r1.read(fileName);
        int p=array.length;
        //////////////////////////
        HashMap<Integer, Character> list = new HashMap<>();
        list.put(0, 'A');
        list.put(1, 'B');
        list.put(2, 'C');
        list.put(3, 'D');
        list.put(4, 'E');
        list.put(5, 'F');
        list.put(6, 'G');
        list.put(7, 'H');
        list.put(8, 'I');
        list.put(9, 'J');
        list.put(10, 'K');
        list.put(11, 'L');
        list.put(12, 'M');
        list.put(13, 'N');
        list.put(14, 'O');
        list.put(15, 'P');
        list.put(16, 'Q');
        list.put(17, 'R');
        list.put(18, 'S');
        list.put(19, 'T');
        list.put(20, 'U');
        list.put(21, 'V');
        list.put(22, 'W');
        list.put(23, 'X');
        list.put(24, 'Y');
        list.put(25, 'Z');
        list.put(26, 'a');
        list.put(27, 'b');
        list.put(28, 'c');
        list.put(29, 'd');
        list.put(30, 'e');
        list.put(31, 'f');
        list.put(32, 'g');
        list.put(33, 'h');
        list.put(34, 'i');
        list.put(35, 'j');
        list.put(36, 'k');
        list.put(37, 'l');
        list.put(38, 'm');
        list.put(39, 'n');
        list.put(40, 'o');
        list.put(41, 'p');
        list.put(42, 'q');
        list.put(43, 'r');
        list.put(44, 's');
        list.put(45, 't');
        list.put(46, 'u');
        list.put(47, 'v');
        list.put(48, 'w');
        list.put(49, 'x');
        list.put(50, 'y');
        list.put(51, 'z');
        list.put(52, '0');
        list.put(53, '1');
        list.put(54, '2');
        list.put(55, '3');
        list.put(56, '4');
        list.put(57, '5');
        list.put(58, '6');
        list.put(59, '7');
        list.put(60, '8');
        list.put(61, '9');
        list.put(62, '+');
        list.put(63, '/');
        int[] arr = new int[(int) (6*ff.length())];
        int[] ar = new int[(int) ff.length()];
        int[] arrx = new int[(int) (6*ff.length())];
        int g = 0;
        int b = 0;
        int key = 0;
        /*we use this loop to find the keys of all chars of code text and put them into array of ints

         */
        for (int f = 0; f <= p - 2; f++) {
            for (key = 0; key < 63; key++) {
                if (list.get(key) == array[f]) {
                    ar[b] = key;
                    //System.out.println(ar[b]);
                    b++;
                    break;
                }

            }

        }
        //////////////////////////////////////
        /*we use this method to change the array of bytes into array of zero and one by cleavage the bytes in two

         */

        for (int u = 0; u <= b - 2; u++) {
            while (ar[u]  != 0) {
                arr[g] = ar[u] % 2;
                //System.out.println(arr[g]);
                ar[u] = ar[u] / 2;
                g++;

            }
            int d = g - 1;
            int k;
            for (k = 0; k <= g - 1; k++) {
                arrx[k] = arr[d];
                //System.out.print(arrx[k]);
                d--;
            }

        }
        ///////////////////////////////////
        int[] arra = new int[(int) ff.length()];
        int kk=g;
        double sum = 0;
        int t = 0;
        int tt = 0;
        int o = 0;
        int power = 7;
        // System.out.println(kk/8);
        /*we use this loop to abrupt array of zero and one eight by eight and carry them to the base two

         */
        int mod=kk%8;
        for (int y = 0; y <(int)kk/8 ; y++) {
            sum = 0;
            power=7;
            for (int z = tt ; z <=tt+7 ; z++) {
                t = (int) ((int) (arr[z] )* pow(2, power));
                sum = sum + t;
                power--;

            }
            tt+=8;
            arra[o] = (int) sum;
            //
             System.out.println(arra[o]);
            o++;


        }
        int kkk=arr.length-1;
        int a[]=new int[8];
        if(mod!=0){
            for(int e=7;e>7-mod;e--){
                a[e]=arr[kkk--];
            }
            for(int ee=0;ee<=7-mod;ee++){
                a[ee]=0;
            }
        }
        outputfilewriter1 w1=new outputfilewriter1();
        w1.write("c:\\users\\mahnoosh\\desktop\\end2.txt",arra);
    }
}