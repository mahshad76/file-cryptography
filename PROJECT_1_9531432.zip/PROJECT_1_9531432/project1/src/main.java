import java.io.*;
import java.nio.charset.Charset;
import java.util.Scanner;


public class main {
    public static void main(String args[]) throws IOException {
        Scanner scanner = new Scanner( System.in );
        System.out.print( "Type some data for the program: " );
        String cmd = scanner.nextLine();
        //String cmd="-dc -r -o c:\\users\\mahnoosh\\desktop\\nn.txt -i c:\\users\\mahnoosh\\desktop\\kk.txt";
        String[] command=cmd.split(" ");
        String filename="";
        String output="";
        boolean flag=false;
        if(command[0].equals("-es")){
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-i")) {
                    filename = command[i + 1];
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-r")) {
                    flag=true;
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-o")) {
                    output=command[i+1];
                    break;
                }
            }

            ///////////////////////
            int a[] = new int[26];
            for (int i = 0; i < 26; i++)
                a[i] = 3;
            File f=new File(filename);
            char[] codes = new char[(int) f.length()];
            int p = 0;
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filename),
                            Charset.forName("UTF-8")));
            int c;
            while ((c = reader.read()) != -1) {
                codes[p] = (char) c;
                p++;

            }
            ////////////////////////////
            simple s = new simple(filename, a);
            ////////////////
            PrintWriter writer = new PrintWriter(output, "UTF-8");
            for(int i=0;i<codes.length;i++) {
                //System.out.print(codes[i]+" "+s.key[i]);
                char b=s.code(codes[i], s.key[i]);
                //////////////
                writer.print(b);
                /////////////
            }
            ///////////////////////
            writer.close();
            ////////////////////////
            if(flag==true) {
                f.deleteOnExit();

            }
        }
        if(command[0].equals("-ds")){
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-i")) {
                    filename = command[i + 1];
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-r")) {
                    flag=true;
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-o")) {
                    output=command[i+1];
                    break;
                }
            }

            ///////////////////////
            int a[] = new int[26];
            for (int i = 0; i < 26; i++)
                a[i] = 3;
            File f=new File(filename);
            char[] codes = new char[(int) f.length()];
            int p = 0;
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filename),
                            Charset.forName("UTF-8")));
            int c;
            while ((c = reader.read()) != -1) {
                codes[p] = (char) c;
                p++;

            }
            ////////////////////////////
            simple s = new simple(filename, a);
            ////////////////
            PrintWriter writer = new PrintWriter(output, "UTF-8");
            for(int i=0;i<codes.length;i++) {
                //System.out.print(codes[i]+" "+s.key[i]);
                char b=s.decode(codes[i], s.key[i]);
                //////////////
                writer.print(b);
                /////////////
            }
            ///////////////////////
            writer.close();
            ////////////////////////
            if(flag==true) {
                f.deleteOnExit();
            }
        }
        if(command[0].equals("-ec")){
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-i")) {
                    filename = command[i + 1];
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-r")) {
                    flag=true;
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-o")) {
                    output=command[i+1];
                    break;
                }
            }
            int a[]=new int[26];
            a[0]=2;
            a[1]=3;
            complex c1 = new complex(filename,a);
            File f=new File(filename);
            char[] codes = new char[(int) f.length()];
            int p = 0;
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filename),
                            Charset.forName("UTF-8")));
            int c;
            while ((c = reader.read()) != -1) {
                codes[p] = (char) c;
                p++;

            }
            PrintWriter writer = new PrintWriter(output, "UTF-8");
            for(int i=0;i<codes.length;i++) {
                // System.out.println(codes[i]+" "+c1.key[i]);
                char uu = c1.code(codes[i], c1.key[i]);
                writer.print(uu);
                /////////////
            }
            ///////////////////////
            writer.close();
            ////////////////////////
            if(flag==true) {
                f.deleteOnExit();
            }
        }
        if(command[0].equals("-dc")){
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-i")) {
                    filename = command[i + 1];
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-r")) {
                    flag=true;
                    break;
                }
            }
            for(int i=0;i<command.length;i++){
                if(command[i].equals("-o")) {
                    output=command[i+1];
                    break;
                }
            }
            int a[]=new int[26];
            a[0]=2;
            a[1]=3;
            complex c1 = new complex(filename,a);
            File f=new File(filename);
            char[] codes = new char[(int) f.length()];
            int p = 0;
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(filename),
                            Charset.forName("UTF-8")));
            int c;
            while ((c = reader.read()) != -1) {
                codes[p] = (char) c;
                p++;

            }
            PrintWriter writer = new PrintWriter(output, "UTF-8");
            for(int i=0;i<codes.length;i++) {
                // System.out.println(codes[i]+" "+c1.key[i]);
                char uu = c1.decode(codes[i], c1.key[i]);
                writer.print(uu);
                /////////////
            }
            ///////////////////////
            writer.close();
            ////////////////////////
            if(flag==true) {
                f.deleteOnExit();
            }
        }


    }
}
