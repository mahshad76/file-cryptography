import java.io.*;
import java.nio.charset.Charset;
import java.util.Scanner;

/*
in this class you can code yor chars but your key for moving is equal for all of your chars that you can find the method for moving in the father class means Base
 */
public class simple extends Base{
    String filename;
    int[] key = new int[26];

    public simple(String filename, int[] key) {
        super(filename, key);
        this.filename = filename;
        this.key = key;
    }

    public int[] getKey() {
        return key;
    }

    public void setKey(int[] key) {
        this.key = key;
    }


}

