import java.io.*;
import java.nio.charset.Charset;


import java.io.*;
import java.nio.charset.Charset;
import java.util.Scanner;

/*
in this class we code your chars by the methods in the father class but in this form we have the array of keys that they
 are not equal
 */

public class complex extends Base {
    String filename;
    int[] key = new int[26];

    public complex(String filename,int[] key) {
        super(filename,key);
        this.filename = filename;
        this.key = key;

    }

    public int[] getKey() {
        return key;
    }

    public void setKey(int[] key) {
        this.key = key;
    }

    ////////////////////////////////////


}

