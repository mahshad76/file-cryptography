import java.io.*;
import java.nio.charset.Charset;
import java.util.Scanner;


public class Base {
    String filename;
    int[] key = new int[26];

    public Base(String filename, int[] key) {
        this.filename = filename;
        this.key = key;
    }

    public int[] getKey() {
        return key;
    }

    public void setKey(int[] key) {
        this.key = key;
    }

    ////////////////////////////////////
    /*we use this method to move your chars and code them but char by char
    you have to find the code char by move the mention char in array of alphabet
    you have to understand if you want to move yor char in the array of alphabet with the mention key do you have enough
    chars before your mention char or you have to start moving from z
    so we have three temper for moving


     */
    public char code(char c, int a) throws IOException {
        char[] alphabet = new char[26];
        char news = 0;
        alphabet[0] = 'A';
        alphabet[1] = 'B';
        alphabet[2] = 'C';
        alphabet[3] = 'D';
        alphabet[4] = 'E';
        alphabet[5] = 'F';
        alphabet[6] = 'G';
        alphabet[7] = 'H';
        alphabet[8] = 'I';
        alphabet[9] = 'J';
        alphabet[10] = 'K';
        alphabet[11] = 'L';
        alphabet[12] = 'M';
        alphabet[13] = 'N';
        alphabet[14] = 'O';
        alphabet[15] = 'P';
        alphabet[16] = 'Q';
        alphabet[17] = 'R';
        alphabet[18] = 'S';
        alphabet[19] = 'T';
        alphabet[20] = 'U';
        alphabet[21] = 'V';
        alphabet[22] = 'W';
        alphabet[23] = 'X';
        alphabet[24] = 'Y';
        alphabet[25] = 'Z';
        if (c == 'A') {
            //System.out.print("kkk");
            news = alphabet[alphabet.length - a];
            return news;
        } else {
            char[] show = new char[filename.length()];
            int sh = 0;
            for (int l = 1; l <= alphabet.length - 2; l++) {
                if (c == alphabet[l]) {
                    /*if key is bigger than the chars you have until A
                    you move your char until A and after that you have to find how many of key is remain and after that
                    moves moves from Z

                     */
                    if (a > l) {
                        int w = alphabet.length - a + l - 1;
                        news = alphabet[w];
                        return news;
                    }
                    /*in this form of keys you have enough chars until A for move

                     */

                    if (a <= l) {
                        news = alphabet[l - a];
                        return news;

                    }
                }
            }
        }
        return 0;

    }

    ///////////////////////
    /*we use this method for move the code chars in the overhand set



     */
    public char decode(char c, int a) throws IOException {
        char[] alphabet = new char[26];
        char news = 0;
        alphabet[0] = 'A';
        alphabet[1] = 'B';
        alphabet[2] = 'C';
        alphabet[3] = 'D';
        alphabet[4] = 'E';
        alphabet[5] = 'F';
        alphabet[6] = 'G';
        alphabet[7] = 'H';
        alphabet[8] = 'I';
        alphabet[9] = 'J';
        alphabet[10] = 'K';
        alphabet[11] = 'L';
        alphabet[12] = 'M';
        alphabet[13] = 'N';
        alphabet[14] = 'O';
        alphabet[15] = 'P';
        alphabet[16] = 'Q';
        alphabet[17] = 'R';
        alphabet[18] = 'S';
        alphabet[19] = 'T';
        alphabet[20] = 'U';
        alphabet[21] = 'V';
        alphabet[22] = 'W';
        alphabet[23] = 'X';
        alphabet[24] = 'Y';
        alphabet[25] = 'Z';
        if (c == 'Z') {
            news = alphabet[a - 1];
            return news;
        }
        //int sh = 0;
        for (int l = 0; l <= alphabet.length - 1; l++) {
            if (c == alphabet[l]) {
                int d = alphabet.length - l;
                /*
                these two temper is like the tempers in code function but in the overhand set
                 */
                if (a < d) {
                    // System.out.println("kk");
                    int w = l + a;
                    news = alphabet[w];
                    return news;
                }
                if (a >= d) {
                    //System.out.println("kkk");
                    int z = alphabet.length - l;
                    a = a - z;
                    int w = a;
                    news = alphabet[w];
                    return news;
                }
            }
        }
        return news;
    }

}

